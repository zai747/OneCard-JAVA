package com.mdot.app.models;

public enum RoleName {
	ROLE_ADMIN, 
	ROLE_USER,
	ROLE_SHOP
}