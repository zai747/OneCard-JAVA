package com.mdot.app.payloads.requests;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OneMediaRequest {


 private String user;
  
 private String title;

 private String image;

 private String description;

 

}


