package com.mdot.app.payloads.requests;

public class FriendRequest {

    private String friend;
    
}
