package com.mdot.app.payloads.requests;

public class FriendRequest {
    
}
