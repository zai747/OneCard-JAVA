package com.mdot.app.payloads.requests;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SocialmediaRequest {
  
   
 private String instagram="";

 private String facebook="";

 private String twitter="";

 private String snapchat="";

 private String linkedin="";

 private String pinterest="";

 private String twitch="";
 

}
