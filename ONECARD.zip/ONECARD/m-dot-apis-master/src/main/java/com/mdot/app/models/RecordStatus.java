package com.mdot.app.models;

public enum RecordStatus {
	DELETED, 
	ACTIVE, 
	INACTIVE,
}
