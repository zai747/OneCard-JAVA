package com.mdot.app.models;

public enum WideRecordStatus {


        DELETED, 
        ACTIVE, 
        INACTIVE,
        BLOCKED,
        INIT,
    }

    